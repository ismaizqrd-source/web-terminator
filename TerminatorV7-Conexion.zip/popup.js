// Popup de la extensión: estado + botón para abrir Vinted.
function setStatus(onVinted) {
  const el = document.getElementById('status');
  if (onVinted) {
    el.className = 'pill green';
    el.innerHTML = '<span class="dot green"></span>Estás en Vinted';
  } else {
    el.className = 'pill muted';
    el.innerHTML = '<span class="dot muted"></span>Abre Vinted para empezar';
  }
}

chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
  const url = (tabs && tabs[0] && tabs[0].url) || '';
  setStatus(/^https:\/\/www\.vinted\.(es|fr)\//.test(url));
});

document.getElementById('open').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://www.vinted.es' });
  window.close();
});
