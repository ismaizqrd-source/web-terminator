/* ============================================================================
   TERMINATOR V7 — Handler del background (service worker)
   Pega esto en tu background.js (o impórtalo). Maneja:
     - T7_USERS   → pide la lista de emails de la app (para el desplegable)
     - T7_CONNECT → captura las cookies de Vinted y las manda al servidor
   El background tiene host_permissions del servidor, así que NO hay CORS.
   ========================================================================== */

const T7_SERVER = 'https://vintedterminator.com';   // <-- cambia si usas otro dominio

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || !msg.type) return;

  if (msg.type === 'T7_CONNECT') {
    handleConnect(msg)
      .then(sendResponse)
      .catch(e => sendResponse({ ok: false, error: String(e.message || e) }));
    return true;
  }
});

async function handleConnect({ token, username_vinted, target_email, motivo }) {
  if (!username_vinted) throw new Error('No se detectó tu usuario de Vinted');

  // 1) Recolectar cookies de Vinted (.es y .fr). chrome.cookies SÍ lee httpOnly.
  let all = [];
  for (const dom of ['vinted.es', 'vinted.fr']) {
    try {
      const cks = await chrome.cookies.getAll({ domain: dom });
      all = all.concat(cks || []);
    } catch (e) {}
  }
  if (!all.length) throw new Error('No se encontraron cookies de Vinted');

  // 2) Deduplicar por nombre, priorizando el dominio .es
  const byName = {};
  for (const c of all) {
    const isEs = (c.domain || '').includes('.es');
    if (!byName[c.name] || isEs) byName[c.name] = c;
  }
  const cookies = Object.values(byName).map(c => ({
    name: c.name, value: c.value,
    domain: c.domain || '.vinted.es', path: c.path || '/',
  }));

  // 3) Enviar al servidor con el token de la extensión
  const r = await fetch(T7_SERVER + '/api/extension/cuenta/add', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-T7-Token': token },
    body: JSON.stringify({
      username_vinted,
      target_email: target_email || '',
      cookies,
      motivo_refresh: motivo || '',
    }),
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok || !data.ok) {
    throw new Error(data.error || ('Error ' + r.status));
  }
  return data;
}
