/* ============================================================================
   TERMINATOR V7 — Overlay de conexión sobre Vinted
   Content script. Se inyecta en www.vinted.es / .fr.
   - Detecta la cuenta de Vinted con la que está logueado el navegador.
   - Pide login con las credenciales de la app (las que tú das al cliente).
   - Botón "Conectar": captura cookies (vía background) y las manda al servidor.
   Todas las llamadas al servidor pasan por el background (sin líos de CORS).
   ========================================================================== */
(() => {
  'use strict';
  if (window.__T7_OVERLAY__) return;          // evitar doble inyección
  window.__T7_OVERLAY__ = true;

  // --- Estado interno -------------------------------------------------------
  const state = {
    vinted: { logged: false, username: '', userId: null },
    open: false,
    connecting: false,
    done: false,
  };

  // Logo (bolt SVG) — coherente con el icono de la extensión
  const BOLT = '<svg class="svgmark" viewBox="0 0 100 100" aria-hidden="true"><defs><linearGradient id="t7g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#78ffe1"/><stop offset="1" stop-color="#0096ff"/></linearGradient></defs><path d="M60 9 L28 54 L47 54 L40 92 L74 45 L55 45 Z" fill="url(#t7g)"/></svg>';

  // --- Shadow host (aislado del CSS y la CSP de Vinted) ---------------------
  const host = document.createElement('div');
  host.id = 't7-overlay-host';
  host.style.cssText = 'all:initial;position:fixed;z-index:2147483647;';
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: 'open' });

  const style = document.createElement('style');
  style.textContent = `
    :host,*{box-sizing:border-box}
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
    .wrap{position:fixed;right:20px;bottom:20px;font-family:'Inter',system-ui,sans-serif}
    /* Launcher pill */
    .launcher{display:flex;align-items:center;gap:9px;background:#0d0d1a;border:1px solid rgba(0,255,204,.25);
      color:#e2e8f0;border-radius:999px;padding:10px 16px;cursor:pointer;box-shadow:0 8px 30px rgba(0,0,0,.45);
      font-size:13px;font-weight:600;transition:transform .15s,border-color .2s}
    .launcher:hover{transform:translateY(-1px);border-color:rgba(0,255,204,.5)}
    .mark{font-weight:800;color:#00ffcc;letter-spacing:-1px}
    .svgmark{width:17px;height:17px;vertical-align:-4px}
    .dot{width:8px;height:8px;border-radius:50%;background:#ef4444;box-shadow:0 0 0 0 rgba(239,68,68,.5);animation:pulse 2s infinite}
    .dot.on{background:#10b981;box-shadow:0 0 0 0 rgba(16,185,129,.5)}
    @keyframes pulse{0%{box-shadow:0 0 0 0 rgba(16,185,129,.45)}70%{box-shadow:0 0 0 7px rgba(16,185,129,0)}100%{box-shadow:0 0 0 0 rgba(16,185,129,0)}}
    @media(prefers-reduced-motion:reduce){.dot{animation:none}}
    /* Card */
    .card{width:340px;background:#0d0d1a;border:1px solid rgba(255,255,255,.07);border-radius:20px;
      box-shadow:0 24px 60px rgba(0,0,0,.55);overflow:hidden;animation:rise .22s ease}
    @keyframes rise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
    @media(prefers-reduced-motion:reduce){.card{animation:none}}
    .head{padding:18px 20px 14px;background:linear-gradient(180deg,rgba(0,255,204,.06),transparent);
      border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;justify-content:space-between}
    .head h1{font-size:15px;font-weight:800;color:#e2e8f0;margin:0;display:flex;align-items:center;gap:8px}
    .x{background:rgba(255,255,255,.06);border:none;color:#94a3b8;width:28px;height:28px;border-radius:50%;
      cursor:pointer;font-size:15px;line-height:1}
    .x:hover{background:rgba(255,255,255,.12);color:#fff}
    .pill{display:inline-flex;align-items:center;gap:7px;font-size:11px;font-weight:600;border-radius:999px;
      padding:5px 11px;margin:0}
    .pill.red{background:rgba(239,68,68,.12);color:#f87171}
    .pill.green{background:rgba(16,185,129,.12);color:#34d399}
    .body{padding:16px 20px 20px}
    .steps{display:flex;flex-direction:column;gap:2px;margin-bottom:14px}
    .step{display:flex;gap:12px;align-items:flex-start;padding:10px 0;position:relative}
    .step:not(:last-child)::after{content:'';position:absolute;left:13px;top:34px;bottom:-2px;width:1.5px;background:rgba(255,255,255,.08)}
    .num{flex:0 0 26px;height:26px;border-radius:50%;display:grid;place-items:center;font-size:12px;font-weight:700;
      background:rgba(255,255,255,.06);color:#64748b;border:1px solid rgba(255,255,255,.08);z-index:1}
    .step.active .num{background:rgba(0,255,204,.12);color:#00ffcc;border-color:rgba(0,255,204,.4)}
    .step.ok .num{background:#10b981;color:#04130d;border-color:#10b981}
    .step .t{font-size:13px;font-weight:600;color:#e2e8f0}
    .step .s{font-size:11.5px;color:#64748b;margin-top:2px;line-height:1.4}
    .step .s b{color:#00ffcc;font-weight:600}
    label{display:block;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:#64748b;margin:0 0 6px}
    select,input{width:100%;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:10px;
      color:#e2e8f0;font-family:inherit;font-size:14px;padding:11px 13px;margin-bottom:12px;outline:none}
    select:focus,input:focus{border-color:#00ffcc}
    select option{background:#0d0d1a}
    .btn{width:100%;background:#00ffcc;color:#04130d;border:none;border-radius:12px;font-family:inherit;font-size:14px;
      font-weight:700;padding:13px;cursor:pointer;transition:opacity .15s}
    .btn:hover{opacity:.9}
    .btn:disabled{opacity:.4;cursor:default}
    .btn.spin{position:relative;color:transparent}
    .btn.spin::after{content:'';position:absolute;inset:0;margin:auto;width:18px;height:18px;border:2px solid rgba(4,19,13,.3);
      border-top-color:#04130d;border-radius:50%;animation:sp .7s linear infinite}
    @keyframes sp{to{transform:rotate(360deg)}}
    .msg{font-size:12px;margin-top:11px;text-align:center;display:none}
    .msg.err{color:#f87171;display:block}
    .msg.note{color:#64748b;display:block}
    .done{text-align:center;padding:14px 8px 6px}
    .done .check{width:56px;height:56px;border-radius:50%;background:rgba(16,185,129,.12);color:#34d399;
      display:grid;place-items:center;font-size:28px;margin:0 auto 14px}
    .done .dt{font-size:16px;font-weight:800;color:#e2e8f0;margin-bottom:4px}
    .done .ds{font-size:12.5px;color:#64748b}
    .hide{display:none!important}
  `;
  root.appendChild(style);

  const wrap = document.createElement('div');
  wrap.className = 'wrap';
  root.appendChild(wrap);

  // --- Render ---------------------------------------------------------------
  function renderLauncher() {
    wrap.innerHTML = `
      <button class="launcher" id="t7-open">
        <span class="dot ${state.vinted.logged ? 'on' : ''}"></span>
        <span class="mark">${BOLT} T7</span>
        <span>${state.vinted.logged ? 'Conectar cuenta' : 'Conectar a Vinted'}</span>
      </button>`;
    wrap.querySelector('#t7-open').addEventListener('click', openCard);
  }

  function renderCard() {
    const v = state.vinted;
    wrap.innerHTML = `
      <div class="card">
        <div class="head">
          <h1><span class="mark">${BOLT}</span> Conecta tu cuenta</h1>
          <button class="x" id="t7-x">✕</button>
        </div>
        <div class="body">
          <div style="margin-bottom:14px">
            <span class="pill ${v.logged ? 'green' : 'red'}">
              <span class="dot ${v.logged ? 'on' : ''}" style="position:static"></span>
              ${v.logged ? 'Sesión de Vinted detectada' : 'Sin sesión de Vinted'}
            </span>
          </div>
          <div class="steps">
            <div class="step ${v.logged ? 'ok' : 'active'}">
              <div class="num">${v.logged ? '✓' : '1'}</div>
              <div>
                <div class="t">Inicia sesión en Vinted</div>
                <div class="s">${v.logged ? 'Conectado como <b>@' + esc(v.username) + '</b>' : 'Abre Vinted e inicia sesión en esta misma pestaña.'}</div>
              </div>
            </div>
            <div class="step ${v.logged ? 'active' : ''}">
              <div class="num">2</div>
              <div style="flex:1">
                <div class="t">Entra con tu cuenta Terminator</div>
                <div class="s" style="margin-bottom:10px">Usa el email y la contraseña que te dieron.</div>
                <label>Email</label>
                <input id="t7-email" type="email" placeholder="tu@email.com" autocomplete="off" autocapitalize="off" spellcheck="false">
                <label>Contraseña</label>
                <input id="t7-pass" type="password" placeholder="••••••••" autocomplete="off">
              </div>
            </div>
            <div class="step">
              <div class="num">3</div>
              <div style="flex:1">
                <div class="t">Conectar</div>
                <div class="s">Se vincula tu Vinted a la app. No se guarda tu contraseña de Vinted.</div>
              </div>
            </div>
          </div>
          <button class="btn" id="t7-connect" ${v.logged ? '' : 'disabled'}>Conectar cuenta</button>
          <div class="msg" id="t7-msg"></div>
        </div>
      </div>`;

    wrap.querySelector('#t7-x').addEventListener('click', closeCard);
    wrap.querySelector('#t7-connect').addEventListener('click', doConnect);
    wrap.querySelector('#t7-pass').addEventListener('keydown', e => { if (e.key === 'Enter') doConnect(); });
  }

  function renderDone() {
    wrap.innerHTML = `
      <div class="card">
        <div class="head"><h1><span class="mark">${BOLT}</span> Conectada</h1><button class="x" id="t7-x">✕</button></div>
        <div class="body"><div class="done">
          <div class="check">✓</div>
          <div class="dt">Cuenta conectada</div>
          <div class="ds">@${esc(state.vinted.username)} ya está vinculada. Puedes cerrar esto.</div>
        </div></div>
      </div>`;
    wrap.querySelector('#t7-x').addEventListener('click', () => { state.done = false; closeCard(); });
    setTimeout(() => { if (state.done) { state.done = false; closeCard(); } }, 4000);
  }

  // --- Acciones -------------------------------------------------------------
  function openCard() { state.open = true; renderCard(); }
  function closeCard() { state.open = false; renderLauncher(); }

  function setMsg(text, kind) {
    const el = wrap.querySelector('#t7-msg');
    if (!el) return;
    el.textContent = text;
    el.className = 'msg ' + (kind || 'note');
  }

  async function detectVinted() {
    try {
      const r = await fetch('/api/v2/users/current', { credentials: 'include', headers: { 'Accept': 'application/json' } });
      if (!r.ok) throw 0;
      const d = await r.json();
      const u = d && d.user;
      if (u && u.id) {
        state.vinted = { logged: true, username: u.login || ('id' + u.id), userId: u.id };
        return;
      }
    } catch (e) {}
    state.vinted = { logged: false, username: '', userId: null };
  }

  async function doConnect() {
    if (state.connecting) return;
    const emailEl = wrap.querySelector('#t7-email');
    const passEl = wrap.querySelector('#t7-pass');
    const email = (emailEl && emailEl.value || '').trim().toLowerCase();
    const pass = (passEl && passEl.value || '').trim();
    if (!state.vinted.logged) { setMsg('Inicia sesión en Vinted primero.', 'err'); return; }
    if (!email || !pass) { setMsg('Pon tu email y contraseña de la app.', 'err'); return; }

    state.connecting = true;
    const btn = wrap.querySelector('#t7-connect');
    btn.classList.add('spin'); btn.disabled = true;
    setMsg('Conectando…', 'note');

    const token = b64(email + ':' + pass);
    try {
      const res = await send({
        type: 'T7_CONNECT',
        token,
        username_vinted: state.vinted.username,
        target_email: email,
        motivo: '',
      });
      if (res && res.ok) {
        state.done = true; state.connecting = false;
        renderDone();
      } else {
        throw new Error((res && res.error) || 'No se pudo conectar');
      }
    } catch (e) {
      state.connecting = false;
      btn.classList.remove('spin'); btn.disabled = false;
      setMsg(String(e.message || e), 'err');
    }
  }

  // --- Utilidades -----------------------------------------------------------
  function esc(s) { return String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }
  function b64(s) { return btoa(unescape(encodeURIComponent(s))); }   // UTF-8 safe
  function send(msg) {
    return new Promise((resolve) => {
      try { chrome.runtime.sendMessage(msg, (r) => resolve(r)); }
      catch (e) { resolve({ ok: false, error: 'Extensión no disponible' }); }
    });
  }

  // --- Init -----------------------------------------------------------------
  (async () => {
    await detectVinted();
    // Si hay sesión de Vinted, abre la tarjeta directa (lo que pediste:
    // "al abrir Vinted, popup para conectar"). Si no, deja el launcher.
    if (state.vinted.logged) { state.open = true; renderCard(); }
    else renderLauncher();
  })();
})();
